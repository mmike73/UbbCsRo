package chat.network.rpcprotocol;


public enum ResponseType {
    OK, ERROR, GET_LOGGED_FRIENDS,UPDATE, NEW_MESSAGE, FRIEND_LOGGED_IN,FRIEND_LOGGED_OUT;
}
