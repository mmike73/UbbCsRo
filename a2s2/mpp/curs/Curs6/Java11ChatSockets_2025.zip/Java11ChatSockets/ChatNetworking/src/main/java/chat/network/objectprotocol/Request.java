package chat.network.objectprotocol;

import java.io.Serializable;


public interface Request extends Serializable{
}
