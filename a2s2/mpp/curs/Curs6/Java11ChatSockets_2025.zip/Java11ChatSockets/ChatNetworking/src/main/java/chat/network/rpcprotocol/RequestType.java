package chat.network.rpcprotocol;


public enum RequestType {
    LOGIN, LOGOUT, GET_LOGGED_FRIENDS, SEND_MESSAGE;
}
