package chat.persistence;

import chat.model.Message;

/**
 * Created by grigo on 3/17/17.
 */
public interface MessageRepository extends ICrudRepository<Integer, Message> {
}
