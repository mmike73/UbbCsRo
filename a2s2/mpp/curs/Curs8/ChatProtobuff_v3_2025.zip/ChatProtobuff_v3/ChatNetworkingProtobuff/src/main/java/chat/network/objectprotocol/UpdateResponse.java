package chat.network.objectprotocol;


public interface UpdateResponse extends Response {
}
