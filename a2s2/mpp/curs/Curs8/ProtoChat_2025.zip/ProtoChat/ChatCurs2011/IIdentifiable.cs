namespace chat.model
{
    public interface IIdentifiable<ID>
    {
        ID Id { get; set; }

    }
}