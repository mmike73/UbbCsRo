﻿namespace services;

public class Class1
{
}