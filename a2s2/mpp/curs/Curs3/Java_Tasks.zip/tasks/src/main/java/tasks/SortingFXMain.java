package tasks;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import tasks.repository.SortingTaskJdbcRepository;
import tasks.repository.SortingTaskRepository;
import tasks.repository.SortingTaskValidator;
import tasks.service.TaskService;
import tasks.utils.ObservableTaskRunner;
import tasks.utils.TaskStack;
import tasks.view.SortingTasksFXML;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class SortingFXMain extends Application{
    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("FXML TableView Example");
        FXMLLoader loader=new FXMLLoader(getClass().getResource("tasks.fxml"));
        Pane myPane = (Pane) loader.load();
       SortingTasksFXML ctrl=loader.getController();

        ctrl.setTasksService(getTasksService());
        Scene myScene = new Scene(myPane);
        primaryStage.setScene(myScene);


        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
              //  System.out.println("Stage is closing");
                ctrl.close();
            }
        });
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    static TaskService  getTasksService(){
          Properties serverProps=new Properties();
        try {
            serverProps.load(new FileReader("bd.config"));
            //System.setProperties(serverProps);

            System.out.println("Properties set. ");
            //System.getProperties().list(System.out);
            serverProps.list(System.out);
        } catch (IOException e) {
            System.err.println("Cannot find bd.config "+e);
            System.err.println("Se cauta fisierul in directorul "+(new File(".")).getAbsolutePath());
            return null;
        }
        SortingTaskJdbcRepository repo=new SortingTaskJdbcRepository(serverProps);//Repository(new SortingTaskValidator());
        //SortingTaskRepository repo=new SortingTaskRepository(new SortingTaskValidator());
        ObservableTaskRunner runner=new ObservableTaskRunner(new TaskStack());
        TaskService service=new TaskService(repo,runner);
        return service;
    }
}
