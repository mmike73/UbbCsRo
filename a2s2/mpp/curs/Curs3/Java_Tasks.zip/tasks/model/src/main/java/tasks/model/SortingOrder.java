package tasks.model;

/**
 * Created by grigo on 11/14/16.
 */
public enum SortingOrder {
    Ascending, Descending;
}
