#!/bin/bash
#clang++ -Wall -g -o magazin main.cpp ui.cpp ui.h service.cpp service.h repo.cpp repo.h domain.cpp domain.h comparatori.cpp comparatori.h validation.cpp validation.h tests.cpp tests.h
clang++ -Wall -g -o magazin main.cpp ui.cpp service.cpp repo.cpp domain.cpp comparatori.cpp validation.cpp tests.cpp
