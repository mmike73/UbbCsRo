//
// Created by Mihai Moldovan on 29.03.2024.
//

#ifndef LAB6_7_TESTS_H
#define LAB6_7_TESTS_H


class Tests {
public:
    void test_domain();
    void test_validation();
    void test_service();
    void run_all_tests();
    void test_cos_bad();
    void test_cos();
};


#endif //LAB6_7_TESTS_H
