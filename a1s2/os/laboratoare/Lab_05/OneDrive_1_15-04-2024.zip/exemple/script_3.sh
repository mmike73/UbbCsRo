#!/bin/bash

echo -n "Enter your name: "
read nume

echo "Hello" $nume
