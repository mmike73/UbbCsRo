#!/bin/bash

for N in {0..5}
do
  echo $N
done
