#!/bin/bash

# print working directory
pwd

# list the content of directory
ls -l
