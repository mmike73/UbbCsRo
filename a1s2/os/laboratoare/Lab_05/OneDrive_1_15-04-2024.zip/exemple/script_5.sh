#!/bin/bash

A=1234
B=5678

echo "$A + $B"
