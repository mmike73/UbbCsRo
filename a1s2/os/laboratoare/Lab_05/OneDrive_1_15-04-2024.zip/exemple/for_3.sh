#!/bin/bash

NAMES='Ana Iulia Maria Tudor'

for N in $NAMES
do
  echo $N
done
