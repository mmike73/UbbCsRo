#!/bin/bash

echo "Enter a number:"
read n

echo "The number was: $n"
