package com.example.guiex1.utils.events;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}
