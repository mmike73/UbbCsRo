rootProject.name = "SocialNetwork"

