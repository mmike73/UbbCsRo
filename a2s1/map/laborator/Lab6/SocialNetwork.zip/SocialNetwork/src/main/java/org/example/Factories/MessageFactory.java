package org.example.Factories;

public class MessageFactory {
}
