package org.example.Entities;

public class Event {
}
