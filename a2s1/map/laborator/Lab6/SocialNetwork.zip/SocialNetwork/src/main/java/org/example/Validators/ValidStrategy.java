package org.example.Validators;

public enum ValidStrategy {
    FRIENDSHIP,
    USER,
}
