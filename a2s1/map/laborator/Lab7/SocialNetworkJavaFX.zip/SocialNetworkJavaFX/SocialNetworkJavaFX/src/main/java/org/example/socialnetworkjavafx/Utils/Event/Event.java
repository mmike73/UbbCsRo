package org.example.socialnetworkjavafx.Utils.Event;

public interface Event {
}
