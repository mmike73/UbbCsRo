package org.example.socialnetworkjavafx.Utils.Event;

public enum ChangeType {
    ADD,
    UPDATE,
    DELETE,
}
