package org.example.socialnetworkjavafx.Validators;

public enum ValidStrategy {
    FRIENDSHIP,
    USER,
}
