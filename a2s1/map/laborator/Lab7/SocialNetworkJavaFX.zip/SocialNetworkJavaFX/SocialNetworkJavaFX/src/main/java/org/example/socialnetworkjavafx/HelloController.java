package org.example.socialnetworkjavafx;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {

}