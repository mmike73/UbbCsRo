namespace Lab9.TaskRunners;

public class PrinterTaskRunner: AbstractTaskRunnner
{
    public PrinterTaskRunner(ITaskRunner taskRunner):base(taskRunner)
    {
    }
    
    public override void ExecuteOneTask()
    {
        _taskRunner.ExecuteOneTask();
        Console.WriteLine("Executed at " + DateTime.Now.ToString("u") + '\n');
    }
}