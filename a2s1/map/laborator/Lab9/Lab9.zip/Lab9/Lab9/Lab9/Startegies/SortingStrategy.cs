namespace Lab9.Sorting;

public enum SortingStrategy
{
    MergeSort,
    BubbleSort,
}