namespace Lab9.Containers;

public enum ContainerStrategy
{
    Lifo,
    Fifo,
}