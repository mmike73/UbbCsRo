namespace Lab9.Sorting;

public abstract class AbstractSorter
{
    public abstract int[] Sort(int[] array);
}