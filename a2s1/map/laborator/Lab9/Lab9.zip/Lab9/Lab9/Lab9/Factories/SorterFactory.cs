using Lab9.Sorting;

namespace Lab9.Factories;

public class SorterFactory
{
    private static SorterFactory SINGLE_INSTANCE = new SorterFactory();

    private SorterFactory()
    {
    }

    public static SorterFactory GetInstance()
    {
        return SINGLE_INSTANCE;
    }

    public AbstractSorter CreateSorter(SortingStrategy strategy)
    {
        return strategy switch
        {
            SortingStrategy.BubbleSort => new BubbleSorter(),
            SortingStrategy.MergeSort => new MergeSorter(),
        };
    }
}