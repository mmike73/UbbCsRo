namespace Lab9.Task;

public abstract class Task
{
    protected string TaskId { get; set; }
    
    protected string Description { get; set; }

    public Task(string taskId, string description)
    {
        this.TaskId = taskId;
        this.Description = description;
    }

    public bool Equals(object? obj)
    {
        if (this == obj) return true;
        if (obj == null || GetType() != obj.GetType()) return false;
        Task? task = (Task)obj;
        return Object.Equals(TaskId, task.TaskId) && Object.Equals(Description, task.Description);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(TaskId, Description);
    }

    public abstract override string ToString();
}