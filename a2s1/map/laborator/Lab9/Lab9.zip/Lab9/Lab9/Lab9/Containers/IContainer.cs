namespace Lab9.Containers;

using Task;

public interface IContainer
{
    Task Remove();
    void Add(Task task);
    int Size();
    Boolean IsEmpty();

}