namespace Lab9.TaskRunners;

using Task;

public interface ITaskRunner
{
    void ExecuteOneTask();
    void ExecuteAll();
    void AddTask(Task task);
    Boolean HasTasks();
}