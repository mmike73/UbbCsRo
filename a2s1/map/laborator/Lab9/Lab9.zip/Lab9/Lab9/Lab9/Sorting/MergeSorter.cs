namespace Lab9.Sorting;

public class MergeSorter: AbstractSorter
{
    private void MergeSort(int[] array, int left, int right)
    {
        if (left < right)
        {
            int mid = left + (right - left) / 2;
            MergeSort(array, left, mid);
            MergeSort(array, mid + 1, right);

            int a = left, b = mid + 1, cnt = 0;
            int[] temp = new int[right - left + 1];

            while (a <= mid && b <= right)
            {
                if (array[a] <= array[b]) temp[cnt++] = array[a++];
                else temp[cnt++] = array[b++];
            }
            
            while (a <= mid) temp[cnt++] = array[a++];
            while (b <= right) temp[cnt++] = array[b++];
            
            for (int k = 0; k < cnt; ++k) 
                array[left + k] = temp[k];
        }
        
        
    }
    public override int[] Sort(int[] array)
    {
        MergeSort(array, 0, array.Length - 1);
        return array;
    }
}