namespace Lab9.Containers;

using Task;
public class QueueContainer : AbstractContainer
{
    public QueueContainer() : base()
    {
    }

    public override Task Remove()
    {
        Task deleted = Tasks[0];
        Tasks.RemoveAt(0);
        return deleted;
    }
}