using System.Collections;
using System.ComponentModel;
using Lab9.Containers;
using IContainer = Lab9.Containers.IContainer;

namespace Lab9.Factories;

public class TaskContainerFactory: Factory
{
    private static Factory SINGLE_INSTANCE = new TaskContainerFactory();

    private TaskContainerFactory()
    {
    }

    public static Factory GetInstance()
    {
        return SINGLE_INSTANCE;
    }
    
    public IContainer CreateContainer(ContainerStrategy containerStrategy)
    {
        return containerStrategy switch
        {
            ContainerStrategy.Fifo => new QueueContainer(),
            ContainerStrategy.Lifo => new StackContainer(),
        };    
    }
}