using System.ComponentModel;
using Lab9.Containers;
using IContainer = Lab9.Containers.IContainer;

namespace Lab9.Factories;

public interface Factory
{
    IContainer CreateContainer(ContainerStrategy containerStrategy);
}