using System.ComponentModel;
using Lab9.Containers;
using Lab9.Factories;
using IContainer = Lab9.Containers.IContainer;


namespace Lab9.TaskRunners;

using Task;

public class StrategyTaskRunner: ITaskRunner
{
    private IContainer Container = null;

    public StrategyTaskRunner(ContainerStrategy strategy)
    {
        Container = TaskContainerFactory.GetInstance().CreateContainer(strategy);
    }

    public void ExecuteOneTask()
    {
        MessageTask t = (MessageTask)Container.Remove();
        t.Execute();
    }

    public void ExecuteAll()
    {
        while (HasTasks())
        {
            ExecuteOneTask();
        }
    }

    public void AddTask(Task task)
    {
        Container.Add(task);
    }

    public bool HasTasks()
    {
        return !Container.IsEmpty();
    }
}