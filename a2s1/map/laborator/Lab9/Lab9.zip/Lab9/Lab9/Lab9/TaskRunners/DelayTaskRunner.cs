namespace Lab9.TaskRunners;

using System.Threading;

public class DelayTaskRunner: AbstractTaskRunnner
{
    public DelayTaskRunner(ITaskRunner taskRunner):base(taskRunner)
    {
    }

    public override void ExecuteOneTask()
    {
        try
        {
            Thread.Sleep(500);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.StackTrace);
        }
        _taskRunner.ExecuteOneTask();
    }
}