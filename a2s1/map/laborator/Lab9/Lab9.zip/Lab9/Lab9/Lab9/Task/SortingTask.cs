using Lab9.Factories;
using Lab9.Sorting;

namespace Lab9.Task;

public class SortingTask: Task
{
    private AbstractSorter _sorter;

    private int[] ToSort;
    
    public SortingTask(string taskId, string description, SortingStrategy strategy, int[] arr) : base(taskId, description)
    {
        _sorter = SorterFactory.GetInstance().CreateSorter(strategy);
        ToSort = arr;
    }

    public void Execute()
    {
        _sorter.Sort(ToSort);
        Console.WriteLine(ToString());
    }

    public override string ToString()
    {
        string result = "";
        foreach (var i in ToSort)
        {
            result = result + i.ToString() + " ";
        }
        result += '\n';

        return result;
    }
}