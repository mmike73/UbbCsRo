using System.ComponentModel;

namespace Lab9.Containers;

using Task;
public class StackContainer : AbstractContainer
{
    public StackContainer(): base()
    {
    }

    public override Task Remove()
    {
        Task deleted = Tasks[Tasks.Count - 1];
        Tasks.RemoveAt(Tasks.Count - 1);
        return deleted;
    }
}