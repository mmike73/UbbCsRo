namespace Lab9.Containers;

using Task;

public abstract class AbstractContainer: IContainer
{
    protected List<Task> Tasks;

    public AbstractContainer()
    {
        Tasks = new List<Task>();
    }

    public abstract Task Remove();

    public void Add(Task task)
    {
        Tasks.Add(task);
    }

    public int Size()
    {
        return Tasks.Count;
    }

    public bool IsEmpty()
    {
        return Tasks.Count == 0;
    }
}