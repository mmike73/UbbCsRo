﻿// See https://aka.ms/new-console-template for more information

/*
 * 1. Y
 * 2. Y
 * 3. Y
 * 4. Y
 * 5. Y
 * 6. Y
 * 7. Y
 * 8. Y
 * 9. Y
 *10. Y
 *11. Y
 *12. Y
 *13. Y
 *14. Y
 *15. Y
 */

using Lab9.Containers;
using Lab9.Factories;
using Lab9.Sorting;
using Lab9.Task;
using Lab9.TaskRunners;

MessageTask[] MessageTasks = new MessageTask[5];

MessageTasks[0] = new MessageTask("0000", "Acordarea premiilor", "Dani - premiul 1", "OSUB", "Dani");
MessageTasks[1] = new MessageTask("0001", "Acordarea premiilor", "Aaron - premiul 2", "OSUB", "Aaron");
MessageTasks[2] = new MessageTask("0002", "Acordarea premiilor", "Mihai - premiul 3", "OSUB", "Mihai");
MessageTasks[3] = new MessageTask("0003", "Acordarea premiilor", "Alex - mentiune 1", "OSUB", "Alex");
MessageTasks[4] = new MessageTask("0004", "Acordarea premiilor", "Andy - mentiune 2", "OSUB", "Andy");


void TestMessageTask()
{
      for (int i = 0; i < MessageTasks.Length; i++)
      {
          MessageTasks[i].Execute();
      }
      
      Console.WriteLine();
}

void TestStrateegyTaskRunner(string strategyName)
{
        StrategyTaskRunner STR = strategyName switch
        {
            "Fifo" => new StrategyTaskRunner(ContainerStrategy.Fifo),
            "Lifo" => new StrategyTaskRunner(ContainerStrategy.Lifo),
        };
        
        for (int i = 0; i < MessageTasks.Length; i++)
        {
            STR.AddTask(MessageTasks[i]);
        }
        
        STR.ExecuteAll();

        Console.WriteLine();
}

void TestStrategyPrintTaskRunner(string strategyName)
{
    StrategyTaskRunner STR = strategyName switch
    {
        "Fifo" => new StrategyTaskRunner(ContainerStrategy.Fifo),
        "Lifo" => new StrategyTaskRunner(ContainerStrategy.Lifo),
    };
    
    for (int i = 0; i < MessageTasks.Length; i++)
    {
        STR.AddTask(MessageTasks[i]);
    }

    PrinterTaskRunner PTR = new PrinterTaskRunner(STR);

    PTR.ExecuteAll();

    Console.WriteLine();

}

void TestStrategyDelayTaskRunner(string strategyName)
{
    StrategyTaskRunner STR = strategyName switch
    {
        "Fifo" => new StrategyTaskRunner(ContainerStrategy.Fifo),
        "Lifo" => new StrategyTaskRunner(ContainerStrategy.Lifo),
    };
    
    for (int i = 0; i < MessageTasks.Length; i++)
    {
        STR.AddTask(MessageTasks[i]);
    }

    DelayTaskRunner DTR = new DelayTaskRunner(STR);

    DTR.ExecuteAll();

    Console.WriteLine();
}

void TestStrategyPrintDelayTaskRunner(string strategyName)
{
    StrategyTaskRunner STR = strategyName switch
    {
        "Fifo" => new StrategyTaskRunner(ContainerStrategy.Fifo),
        "Lifo" => new StrategyTaskRunner(ContainerStrategy.Lifo),
    };
    
    for (int i = 0; i < MessageTasks.Length; i++)
    {
        STR.AddTask(MessageTasks[i]);
    }

    PrinterTaskRunner PTR = new PrinterTaskRunner(STR);
    //PTR.ExecuteAll();
    DelayTaskRunner DTR = new DelayTaskRunner(PTR);
    
    // nu e delayed
    DTR.ExecuteAll();

    Console.WriteLine();

}

TestMessageTask();
TestStrateegyTaskRunner(args[0]);
TestStrategyPrintTaskRunner(args[0]);
TestStrategyDelayTaskRunner(args[0]);
TestStrategyPrintDelayTaskRunner(args[0]);
