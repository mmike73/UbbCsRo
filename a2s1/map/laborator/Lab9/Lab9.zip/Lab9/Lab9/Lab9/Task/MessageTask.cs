namespace Lab9.Task;

public class MessageTask: Task
{
    private string Message { get; set; }
    
    private string From { get; set; }
    
    private string To { get; set; }
    
    private DateTime Date { get; set; }
    
    public MessageTask(string taskId, string description, string message, string from, string to) : base(taskId, description)
    {
        From = from;
        To = to;
        Message = message;
        Date = DateTime.Now;
    }

    public void Execute()
    {
        Console.WriteLine(Date.ToString("f") + " " + Message);
    }

    public override string ToString()
    {
        return "id=" + TaskId.ToString() + "|description=" + Description + "message|" + Message + "|from=" + From + "|to=" + To + "|date=" + Date.ToString("u") + '\n';
    }
}