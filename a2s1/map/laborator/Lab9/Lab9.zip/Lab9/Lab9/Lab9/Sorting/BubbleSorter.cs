namespace Lab9.Sorting;

public class BubbleSorter: AbstractSorter
{
    public override int[] Sort(int[] array)
    {
        bool sorted = false;
        while (!sorted )
        {
            sorted = true;
            for (int i = 0; i < array.Length - 1; ++i)
            {
                if (array[i] > array[i + 1])
                {
                    int tmp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = tmp;
                    sorted = false;
                }
            }
            
        }

        return array;
    }
}