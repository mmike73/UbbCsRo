namespace Lab9.TaskRunners;

using Task;

public abstract class AbstractTaskRunnner: ITaskRunner
{
    protected ITaskRunner _taskRunner;

    public AbstractTaskRunnner(ITaskRunner taskRunner)
    {
        this._taskRunner = taskRunner;
    }

    public virtual void ExecuteOneTask()
    {
        _taskRunner.ExecuteOneTask();
    }

    public void ExecuteAll()
    {
        while (HasTasks())
        {
            this.ExecuteOneTask();
        }
    }

    public void AddTask(Task task)
    {
        _taskRunner.AddTask(task);
    }

    public bool HasTasks()
    {
        return _taskRunner.HasTasks();
    }
}