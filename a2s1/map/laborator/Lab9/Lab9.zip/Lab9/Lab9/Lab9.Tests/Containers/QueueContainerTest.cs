using JetBrains.Annotations;
using Lab9.Containers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab9.Tests.Containers;

[TestClass]
[TestSubject(typeof(QueueContainer))]
public class QueueContainerTest
{

    [TestMethod]
    public void METHOD()
    {
        
    }
}