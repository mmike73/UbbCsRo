using System;
using System.IO;
using JetBrains.Annotations;
using Lab9.Containers;
using Lab9.Task;
using Lab9.TaskRunners;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab9.Tests.TaskRunners;

[TestClass]
[TestSubject(typeof(PrinterTaskRunner))]
public class PrinterTaskRunnerTest
{

    [TestMethod]
    public void METHOD()
    {
        
        
    }
}