using JetBrains.Annotations;
using Lab9.Task;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab9.Tests.Task;

[TestClass]
[TestSubject(typeof(MessageTask))]
public class MessageTaskTest
{

    [TestMethod]
    public void METHOD()
    {
        
    }
}