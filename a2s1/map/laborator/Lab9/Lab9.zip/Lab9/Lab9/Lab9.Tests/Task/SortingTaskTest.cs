using System.Collections.Generic;
using JetBrains.Annotations;
using Lab9.Containers;
using Lab9.Sorting;
using Lab9.Task;
using Lab9.TaskRunners;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab9.Tests.Task;

using Task;

[TestClass]
[TestSubject(typeof(SortingTask))]
public class SortingTaskTest
{

    [TestMethod]
    public void METHOD()
    {
        List<Lab9.Task.Task> tasks = new List<Lab9.Task.Task>();
        tasks.Add(new SortingTask("0", "MergeSort this arr", SortingStrategy.MergeSort, new int[] { 6, 3, 5, 6, 20, 6, 1, 2, 4, 34, 123, -5 }));
        tasks.Add(new SortingTask("1", "BubbleSort this arr", SortingStrategy.BubbleSort, new int[] { 6, 3, 5, 6, 20, 6, 1, 2, 4, 34, 123, -5 }));
        tasks.Add(new SortingTask("2", "MergeSort this arr", SortingStrategy.MergeSort, new int[] { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 }));
        tasks.Add(new SortingTask("3", "MergeSort this arr", SortingStrategy.BubbleSort, new int[] { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 }));
        tasks.Add(new SortingTask("4", "MergeSort this arr", SortingStrategy.MergeSort, new int[] {1, 1, 1, 1, 1 }));
        
    }
}