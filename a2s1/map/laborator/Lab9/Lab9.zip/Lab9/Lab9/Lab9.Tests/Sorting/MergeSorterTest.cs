using System;
using JetBrains.Annotations;
using Lab9.Factories;
using Lab9.Sorting;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab9.Tests.Sorting;

[TestClass]
[TestSubject(typeof(BubbleSorter))]
public class MergeSorterTest
{

    [TestMethod]
    public void METHOD()
    {
        AbstractSorter sorter = SorterFactory.GetInstance().CreateSorter(SortingStrategy.MergeSort);
        Console.WriteLine(sorter.Sort(new int[] { 6, 3, 5, 6, 20, 6, 1, 2, 4, 34, 123, -5 }));
        CollectionAssert.AreEqual(sorter.Sort(new int[] { 6, 3, 5, 6, 20, 6, 1, 2, 4, 34, 123, -5 }),
                                                   new int[] { -5, 1, 2, 3, 4, 5, 6, 6, 6, 20, 34, 123 });
        CollectionAssert.AreEqual(sorter.Sort( new int[] { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 }),
                                                    new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 });
        CollectionAssert.AreEqual(sorter.Sort(new int[] {1, 1, 1, 1, 1 }),
                                                   new int[] {1, 1, 1, 1, 1 });
        CollectionAssert.AreEqual(sorter.Sort(new int[] {}),
                                                   new int[] {});
    }
}