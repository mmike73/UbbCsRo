using JetBrains.Annotations;
using Lab9.Task;
using Lab9.TaskRunners;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab9.Tests.TaskRunners;

[TestClass]
[TestSubject(typeof(DelayTaskRunner))]
public class DelayTaskRunnerTest
{

    [TestMethod]
    public void METHOD()
    {
        
    }
}