using JetBrains.Annotations;
using Lab9.TaskRunners;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using Lab9.Containers;
using Lab9.Task;

namespace Lab9.Tests.TaskRunners;

[TestClass]
[TestSubject(typeof(StrategyTaskRunner))]
public class StrategyTaskRunnerTest
{

    [TestMethod]
    public void METHOD()
    {
        MessageTask[] MessageTasks = new MessageTask[5];

        MessageTasks[0] = new MessageTask("0000", "Acordarea premiilor", "Dani - premiul 1", "OSUB", "Dani");
        MessageTasks[1] = new MessageTask("0001", "Acordarea premiilor", "Aaron - premiul 2", "OSUB", "Aaron");
        MessageTasks[2] = new MessageTask("0002", "Acordarea premiilor", "Mihai - premiul 3", "OSUB", "Mihai");
        MessageTasks[3] = new MessageTask("0003", "Acordarea premiilor", "Alex - mentiune 1", "OSUB", "Alex");
        MessageTasks[4] = new MessageTask("0004", "Acordarea premiilor", "Andy - mentiune 2", "OSUB", "Andy");

        StrategyTaskRunner STR = new StrategyTaskRunner(ContainerStrategy.Fifo);

        for (int i = 0; i < MessageTasks.Length; i++)
        {
            STR.AddTask(MessageTasks[i]);
        }

        PrinterTaskRunner PTR = new PrinterTaskRunner(STR);

        string captureOutput;
        using (StringWriter stringWriter = new StringWriter())
        {
            Console.SetOut(stringWriter);
            
            PTR.ExecuteAll();
            
            captureOutput = stringWriter.ToString();
        }
        string expected = "Thursday, 12 December 2024 17:00 Dani - premiul 1\n" +
                          "Thursday, 12 December 2024 17:00 Aaron - premiul 2\\n" +
                          "Thursday, 12 December 2024 17:00 Mihai - premiul 3\\n" +
                          "Thursday, 12 December 2024 17:00 Alex - mentiune 1\\n" +
                          "Thursday, 12 December 2024 17:00 Andy - mentiune 2";

  
    }
}