package sem1_2.factory;

public enum Strategy {
    LIFO, FIFO;
}
