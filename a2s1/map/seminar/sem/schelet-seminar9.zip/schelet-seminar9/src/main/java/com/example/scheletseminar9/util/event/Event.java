package com.example.scheletseminar9.util.event;

public interface Event {
}
