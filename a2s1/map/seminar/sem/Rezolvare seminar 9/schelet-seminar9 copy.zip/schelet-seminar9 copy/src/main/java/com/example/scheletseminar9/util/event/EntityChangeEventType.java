package com.example.scheletseminar9.util.event;

public enum EntityChangeEventType {
    ADD,
    UPDATE,
    DELETE;
}
