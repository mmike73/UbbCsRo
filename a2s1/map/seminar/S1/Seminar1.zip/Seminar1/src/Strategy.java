public enum Strategy {
    LIFO,FIFO
}
