public interface Factory {
    Container createContainer(Strategy strategy);
}
